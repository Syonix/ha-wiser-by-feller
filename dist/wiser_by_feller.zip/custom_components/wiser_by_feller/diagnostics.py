"""Diagnostics support for Wiser by Feller integration."""

from __future__ import annotations

import json
from typing import Any

from homeassistant.components.diagnostics import async_redact_data
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceEntry

from .coordinator import WiserCoordinator

TO_REDACT = ("token", "serial_nr", "serial_number", "sn", "instance_id", "identifiers")


async def async_get_config_entry_diagnostics(
    hass: HomeAssistant, entry: ConfigEntry
) -> dict[str, Any]:
    """Return diagnostics for a config entry."""
    coordinator: WiserCoordinator = entry.runtime_data

    # Diagnostics should never fail just because some data has not (yet) loaded.
    # Missing sections are emitted as empty rather than raising.
    loads_json = [load.raw_data for load in (coordinator.loads or {}).values()]
    devices_json = [device.raw_data for device in (coordinator.devices or {}).values()]
    gateway_info_json = coordinator.gateway_info

    sensors_json = (
        [sensor.raw_data for sensor in coordinator.sensors.values()]
        if coordinator.sensors
        else []
    )

    return {
        "entry_data": async_redact_data(entry.data, TO_REDACT),
        "gateway_info": async_redact_data(gateway_info_json, TO_REDACT),
        "loads": async_redact_data(loads_json, TO_REDACT),
        "rooms": async_redact_data(coordinator.rooms or {}, TO_REDACT),
        "devices": async_redact_data(devices_json, TO_REDACT),
        "scenes": async_redact_data(
            [scene.raw_data for scene in (coordinator.scenes or {}).values()], TO_REDACT
        ),
        "sensors": async_redact_data(sensors_json, TO_REDACT),
    }


async def async_get_device_diagnostics(
    hass: HomeAssistant, entry: ConfigEntry, device: DeviceEntry
) -> dict[str, Any]:
    """Return diagnostics for a device."""
    coordinator: WiserCoordinator = entry.runtime_data
    result: dict[str, Any] = {}
    result["device"] = async_redact_data(
        json.loads(device.json_repr or b"{}"), TO_REDACT
    )

    if device.name == f"{entry.title} µGateway":
        result["gateway_info"] = async_redact_data(coordinator.gateway_info, TO_REDACT)
        result["scenes"] = async_redact_data(
            [scene.raw_data for scene in (coordinator.scenes or {}).values()], TO_REDACT
        )
    else:
        device_id = next(iter(device.identifiers))[1].partition("_")[0]
        wiser_device = (coordinator.devices or {}).get(device_id)
        if wiser_device is not None:
            result["device_data"] = async_redact_data(wiser_device.raw_data, TO_REDACT)

    return result
